import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { matSelectAnimations } from '@angular/material/select';
import { Donor } from 'src/app/Interfaces/Donor';
import { DonacionService } from 'src/app/Servicios/donacion.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})

export class FormComponent implements OnInit {
form:FormGroup

constructor(private fb: FormBuilder,
  private _donacionService: DonacionService) {
  this.form = this.fb.group ({
   
    nombre : ['', Validators.required],
    apellido : ['', Validators.required],
    direccion : ['', Validators.required],
    email : ['', Validators.required],
    telefono : ['', Validators.required],
    anonimo : ['', Validators.required],
    estado : ['', Validators.required],
    nombre_orden : ['', Validators.required],
    cantidad : ['', Validators.required],
    fecha_recojo : ['', Validators.required],
    contacto : ['', Validators.required],
    tipo : ['', Validators.required],
    
  })

}
ngOnInit() : void {
}
 
agregarDonacion () {
  console.log ('cec');
  

  const nombre = this.form.value.nombre 
 
  //armando objeto
  const donacion: Donor = {
    nombre: this.form.value.nombre,
    apellido: this.form.value.apellido,
    direccion: this.form.value.direccion,
    email: this.form.value.email,
    telefono: this.form.value.telefono,
    anonimo: this.form.value.anonimo,
    estado: this.form.value.estado,
    nombre_orden: this.form.value.nombre_orden, 
    cantidad: this.form.value.cantidad,
    fecha_recojo: this.form.value.fecha_recojo, 
    contacto: this.form.value.contacto,
    tipo: this.form.value.tipo
  }
 //enviar objeto a backend
 this._donacionService.addDonacion (donacion).subscribe (data => {

    console.log (data);


 }) 
}
}

