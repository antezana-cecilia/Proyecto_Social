import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioDonacionComponent } from './formulario-donacion.component';

describe('FormularioDonacionComponent', () => {
  let component: FormularioDonacionComponent;
  let fixture: ComponentFixture<FormularioDonacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormularioDonacionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormularioDonacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
