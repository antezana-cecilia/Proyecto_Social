import { Component } from '@angular/core';

@Component({
  selector: 'app-formulario-donacion',
  templateUrl: './formulario-donacion.component.html',
  styleUrls: ['./formulario-donacion.component.css']
})
export class FormularioDonacionComponent {

}
