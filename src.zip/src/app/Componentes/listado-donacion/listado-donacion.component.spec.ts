import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoDonacionComponent } from './listado-donacion.component';

describe('ListadoDonacionComponent', () => {
  let component: ListadoDonacionComponent;
  let fixture: ComponentFixture<ListadoDonacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListadoDonacionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListadoDonacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
