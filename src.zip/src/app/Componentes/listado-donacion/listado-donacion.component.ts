import { Component } from '@angular/core';

@Component({
  selector: 'app-listado-donacion',
  templateUrl: './listado-donacion.component.html',
  styleUrls: ['./listado-donacion.component.css']
})
export class ListadoDonacionComponent {

}
