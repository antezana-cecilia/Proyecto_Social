import { Component } from '@angular/core';


@Component({
  selector: 'app-ver-donacion',
  templateUrl: './ver-donacion.component.html',
  styleUrls: ['./ver-donacion.component.css']
})
export class VerDonacionComponent {

}