export interface Donor {
    id?:number;
    nombre:string;
    apellido :string;
    email:string;
    direccion:string;
    telefono:number;
    anonimo:string;
    estado:string;
    nombre_orden:string;
    cantidad:number;
    fecha_recojo:string;
    contacto:string;
    tipo:string;
}
 