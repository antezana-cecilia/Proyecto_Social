import { NgModule } from '@angular/core';
import { FormRecord } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AgregarModificarEliminarComponent } from './Componentes/agregar-modificar-eliminar/agregar-modificar-eliminar.component';
import { EditarComponent } from './Componentes/editar/editar.component';
import { FormComponent } from './Componentes/form/form.component';
import { FormularioDonacionComponent } from './Componentes/formulario-donacion/formulario-donacion.component';
import { FrontComponent } from './Componentes/front/front.component';
import { ListadoDonacionComponent } from './Componentes/listado-donacion/listado-donacion.component';
import { VerDonacionComponent } from './Componentes/ver-donacion/ver-donacion.component';
import { AgruparComponent } from './Componentes/agrupar/agrupar.component';
import { ContactoComponent } from './Componentes/contacto/contacto.component';
//import { FormComponent } from './Componentes/form/form.component';

const routes: Routes = [

  {path: "",redirectTo:"Front", pathMatch:"full"  },


  {path: "agregar",component:AgregarModificarEliminarComponent},
  {path: "form",component:FormComponent},
  {path: "Front",component:FrontComponent},
  
  {path: "listar/:id",component:ListadoDonacionComponent},
  {path: "editar/:id",component:AgregarModificarEliminarComponent},
  {path: "agrupar/:id",component:AgruparComponent},
  {path: "contacto",component:ContactoComponent},

  {path: "**",redirectTo:"Front", pathMatch:"full"},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
