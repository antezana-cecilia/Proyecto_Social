import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgregarModificarEliminarComponent } from './Componentes/agregar-modificar-eliminar/agregar-modificar-eliminar.component';
import { AgruparComponent } from './Componentes/agrupar/agrupar.component';
import { ListadoDonacionComponent } from './Componentes/listado-donacion/listado-donacion.component';
import { VerDonacionComponent } from './Componentes/ver-donacion/ver-donacion.component';
import { EditarComponent } from './Componentes/editar/editar.component';
import { ContactoComponent } from './Componentes/contacto/contacto.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';




//Importar http
import { HttpClientModule } from '@angular/common/http';
import { FormComponent } from './Componentes/form/form.component';
import { FrontComponent } from './Componentes/front/front.component';
import { SharedModule } from './shared/shared.module';

//angular material
@NgModule({
  declarations: [
  AppComponent,
  AgregarModificarEliminarComponent,
  AgruparComponent,
  FormComponent,
  FrontComponent,
  ListadoDonacionComponent,
  VerDonacionComponent,
  EditarComponent,
  ContactoComponent
   
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    SharedModule



  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
