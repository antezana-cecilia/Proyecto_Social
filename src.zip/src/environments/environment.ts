



export const enviromemt = {

production: false,
endpoint: 'https://localhost:7200'

};